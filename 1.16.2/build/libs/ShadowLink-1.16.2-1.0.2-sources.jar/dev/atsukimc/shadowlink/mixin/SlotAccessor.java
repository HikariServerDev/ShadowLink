package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1735;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

/** Slot#getIndex only exists from 1.17 on. */
@Mixin(class_1735.class)
public interface SlotAccessor {
    @Accessor("index")
    int shadowlink$getIndex();
}
