package dev.atsukimc.shadowlink.mixin;

import dev.atsukimc.shadowlink.core.ShadowManager;
import net.minecraft.class_1263;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2586;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_2818.class)
public abstract class WorldChunkMixin {
    @Shadow @Final private class_1937 world;
    @Shadow private boolean loadedToWorld;

    /**
     * Runs once the chunk's contents are in place but before its block entities are handed to
     * the world (loadedToWorld is still false), so re-linking never registers anything twice.
     */
    @Inject(method = "loadToWorld", at = @At("TAIL"))
    private void shadowlink$loaded(CallbackInfo ci) {
        if (!this.loadedToWorld && this.world instanceof class_3218) {
            ShadowManager.onChunkLoaded((class_3218) this.world, (class_2818) (Object) this);
        }
    }

    /** Called with {@code false} immediately before the chunk is serialized for unloading. */
    @Inject(method = "setLoadedToWorld", at = @At("TAIL"))
    private void shadowlink$unloading(boolean loaded, CallbackInfo ci) {
        if (!loaded && this.world instanceof class_3218) {
            ShadowManager.onChunkUnloading((class_3218) this.world, (class_2818) (Object) this);
        }
    }

    // A block entity put into an already loaded chunk (placed, or moved by a piston with
    // Carpet's movable block entities) may carry a tracked stack to a new position.
    @Inject(method = "setBlockEntity", at = @At("TAIL"))
    private void shadowlink$blockEntitySet(class_2338 pos, class_2586 blockEntity, CallbackInfo ci) {
        if (this.loadedToWorld && blockEntity instanceof class_1263 && this.world instanceof class_3218) {
            ShadowManager.onBlockEntityPlaced((class_3218) this.world, blockEntity);
        }
    }
}
