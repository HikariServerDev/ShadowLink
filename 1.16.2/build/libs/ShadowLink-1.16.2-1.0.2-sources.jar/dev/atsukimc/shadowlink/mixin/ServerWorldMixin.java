package dev.atsukimc.shadowlink.mixin;

import dev.atsukimc.shadowlink.core.ShadowManager;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import net.minecraft.class_3218;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Load / unload of inventory-carrying entities (storage minecarts, horses, donkeys, llamas). */
@Mixin(class_3218.class)
public abstract class ServerWorldMixin {
    @Inject(method = "loadEntityUnchecked", at = @At("TAIL"))
    private void shadowlink$loaded(class_1297 entity, CallbackInfo ci) {
        if (entity instanceof class_1263 || entity instanceof class_1496) {
            ShadowManager.onEntityLoaded(entity);
        }
    }

    // Reached both for a chunk unload and for removal (death, portal); the manager tells them
    // apart by Entity#removed.
    @Inject(method = "unloadEntity", at = @At("HEAD"))
    private void shadowlink$unloading(class_1297 entity, CallbackInfo ci) {
        if (entity instanceof class_1263 || entity instanceof class_1496) {
            ShadowManager.onEntityUnloading(entity);
        }
    }
}
