package dev.atsukimc.shadowlink.core;

import dev.atsukimc.shadowlink.mixin.AbstractFurnaceBlockEntityAccessor;
import dev.atsukimc.shadowlink.mixin.HorseBaseEntityAccessor;
import dev.atsukimc.shadowlink.mixin.LootableContainerBlockEntityInvoker;
import dev.atsukimc.shadowlink.mixin.SimpleInventoryAccessor;
import dev.atsukimc.shadowlink.mixin.StorageMinecartEntityAccessor;
import net.minecraft.class_1263;
import net.minecraft.class_1277;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import net.minecraft.class_1693;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2487;
import net.minecraft.class_2609;
import net.minecraft.class_2621;

/**
 * Side-effect free slot access.
 * <p>
 * {@code Inventory.getStack/setStack} are not neutral on several vanilla inventories: lootable
 * containers and chest minecarts generate their loot table, furnaces reset their cook timer,
 * SimpleInventory notifies listeners and most of them clamp the stack count and fire
 * comparator updates. Observing or re-linking a shadow must cause none of that, so the
 * backing list is used directly wherever vanilla has one.
 */
final class InventoryAccess {
    private static final class_2487 EMPTY_SNAPSHOT = new class_2487();

    private InventoryAccess() {
    }

    private static class_2371<class_1799> backingList(class_1263 inventory) {
        if (inventory instanceof class_2621) {
            return ((LootableContainerBlockEntityInvoker) inventory).shadowlink$getInvStackList();
        }
        if (inventory instanceof class_2609) {
            return ((AbstractFurnaceBlockEntityAccessor) inventory).shadowlink$getInventory();
        }
        if (inventory instanceof class_1693) {
            return ((StorageMinecartEntityAccessor) inventory).shadowlink$getInventory();
        }
        if (inventory instanceof class_1277) {
            return ((SimpleInventoryAccessor) inventory).shadowlink$getStacks();
        }
        // PlayerInventory, BrewingStandBlockEntity: plain getStack/setStack without side effects.
        return null;
    }

    static int size(class_1263 inventory) {
        class_2371<class_1799> list = backingList(inventory);
        return list != null ? list.size() : inventory.method_5439();
    }

    static class_1799 get(class_1263 inventory, int slot) {
        class_2371<class_1799> list = backingList(inventory);
        if (list != null) {
            return slot >= 0 && slot < list.size() ? list.get(slot) : class_1799.field_8037;
        }
        return slot >= 0 && slot < inventory.method_5439() ? inventory.method_5438(slot) : class_1799.field_8037;
    }

    static void set(class_1263 inventory, int slot, class_1799 stack) {
        class_2371<class_1799> list = backingList(inventory);
        if (list != null) {
            list.set(slot, stack);
        } else {
            inventory.method_5447(slot, stack);
        }
    }

    /** The slot container of an entity, or null if this entity type is not tracked. */
    static class_1263 inventoryOf(class_1297 entity) {
        if (entity instanceof class_1263) {
            return (class_1263) entity;
        }
        if (entity instanceof class_1496) {
            return ((HorseBaseEntityAccessor) entity).shadowlink$getItems();
        }
        return null;
    }

    /**
     * NBT form of a stack as it looks after one save/load cycle. Loading is not an exact
     * inverse of saving (e.g. damageable items gain {@code Damage:0}), so both sides of every
     * comparison go through the same round trip. Empty stacks are an empty compound.
     */
    static class_2487 snapshotOf(class_1799 stack) {
        if (stack == null || stack.method_7960()) {
            return EMPTY_SNAPSHOT;
        }
        class_1799 reloaded = class_1799.method_7915(stack.method_7953(new class_2487()));
        if (reloaded.method_7960()) {
            return EMPTY_SNAPSHOT;
        }
        return reloaded.method_7953(new class_2487());
    }

    static class_1799 fromSnapshot(class_2487 snapshot) {
        // fromNbt may post-process the compound in place, hence the copy.
        return snapshot.isEmpty() ? class_1799.field_8037 : class_1799.method_7915(snapshot.method_10553());
    }
}
