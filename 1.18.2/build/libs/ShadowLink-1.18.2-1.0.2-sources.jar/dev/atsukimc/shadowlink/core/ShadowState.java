package dev.atsukimc.shadowlink.core;

import net.minecraft.class_18;
import net.minecraft.class_2487;

/** Vanilla save-data carrier: {@code <world>/data/shadowlink.dat}, written with every world save. */
final class ShadowState extends class_18 {
    static final String ID = "shadowlink";

    private final ShadowManager manager;

    ShadowState(ShadowManager manager) {
        this.manager = manager;
    }

    @Override
    public class_2487 method_75(class_2487 nbt) {
        return this.manager.writeNbt(nbt);
    }

    /**
     * The saved snapshot has to describe the canonical stacks as they are at save time, and
     * those change without notifying anyone, so the state is rewritten on every save while
     * at least one group exists.
     */
    @Override
    public boolean method_79() {
        return super.method_79() || this.manager.hasGroups();
    }
}
