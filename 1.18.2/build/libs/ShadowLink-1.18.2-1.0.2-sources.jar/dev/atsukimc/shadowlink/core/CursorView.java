package dev.atsukimc.shadowlink.core;

import net.minecraft.class_1263;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_3222;

/** Read-only single-slot view of a player's cursor stack, so it can be scanned like any holder. */
final class CursorView implements class_1263 {
    private final class_3222 player;

    CursorView(class_3222 player) {
        this.player = player;
    }

    @Override
    public int method_5439() {
        return 1;
    }

    @Override
    public boolean method_5442() {
        return this.method_5438(0).method_7960();
    }

    @Override
    public class_1799 method_5438(int slot) {
        return this.player.field_7512 == null ? class_1799.field_8037 : this.player.field_7512.method_34255();
    }

    @Override
    public class_1799 method_5434(int slot, int amount) {
        throw new UnsupportedOperationException();
    }

    @Override
    public class_1799 method_5441(int slot) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void method_5447(int slot, class_1799 stack) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void method_5431() {
    }

    @Override
    public boolean method_5443(class_1657 player) {
        return false;
    }

    @Override
    public void method_5448() {
        throw new UnsupportedOperationException();
    }
}
