package dev.atsukimc.shadowlink.mixin;

import dev.atsukimc.shadowlink.core.ShadowManager;
import net.minecraft.class_2535;
import net.minecraft.class_3222;
import net.minecraft.class_3324;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/**
 * Real players and Carpet fake players both enter and leave through these two methods, so
 * hooking them covers every ServerPlayerEntity without referencing Carpet.
 */
@Mixin(class_3324.class)
public abstract class PlayerManagerMixin {
    @Inject(method = "onPlayerConnect", at = @At("TAIL"))
    private void shadowlink$joined(class_2535 connection, class_3222 player, CallbackInfo ci) {
        ShadowManager.onPlayerJoined(player);
    }

    // HEAD: the inventory is still intact and is about to be written to the player file.
    @Inject(method = "remove", at = @At("HEAD"))
    private void shadowlink$leaving(class_3222 player, CallbackInfo ci) {
        ShadowManager.onPlayerLeaving(player);
    }
}
