package dev.atsukimc.shadowlink.mixin;

import dev.atsukimc.shadowlink.core.ShadowManager;
import net.minecraft.class_1657;
import net.minecraft.class_1703;
import net.minecraft.class_1713;
import net.minecraft.class_3222;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1703.class)
public abstract class ScreenHandlerMixin {
    // HEAD rather than RETURN: the click that creates a shadow ends in an exception, so the
    // handler is only queued here and inspected afterwards by ShadowManager.
    @Inject(method = "onSlotClick", at = @At("HEAD"))
    private void shadowlink$clicked(int slotIndex, int button, class_1713 actionType, class_1657 player, CallbackInfo ci) {
        if (player instanceof class_3222 serverPlayer) {
            ShadowManager.onSlotClick((class_1703) (Object) this, serverPlayer);
        }
    }
}
