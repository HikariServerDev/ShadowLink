package dev.atsukimc.shadowlink.mixin;

import dev.atsukimc.shadowlink.core.ShadowManager;
import net.minecraft.class_1263;
import net.minecraft.class_1297;
import net.minecraft.class_1496;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Load / unload of inventory-carrying entities (storage minecarts, horses, donkeys, llamas). */
@Mixin(targets = "net.minecraft.server.world.ServerWorld$ServerEntityHandler")
public abstract class ServerEntityHandlerMixin {
    @Inject(method = "startTracking(Lnet/minecraft/entity/Entity;)V", at = @At("TAIL"))
    private void shadowlink$loaded(class_1297 entity, CallbackInfo ci) {
        if (entity instanceof class_1263 || entity instanceof class_1496) {
            ShadowManager.onEntityLoaded(entity);
        }
    }

    @Inject(method = "stopTracking(Lnet/minecraft/entity/Entity;)V", at = @At("HEAD"))
    private void shadowlink$unloading(class_1297 entity, CallbackInfo ci) {
        if (entity instanceof class_1263 || entity instanceof class_1496) {
            ShadowManager.onEntityUnloading(entity);
        }
    }
}
