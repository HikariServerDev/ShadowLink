package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2609;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2609.class)
public interface AbstractFurnaceBlockEntityAccessor {
    @Accessor("inventory")
    class_2371<class_1799> shadowlink$getInventory();
}
