package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1799;
import net.minecraft.class_2371;
import net.minecraft.class_2621;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2621.class)
public interface LootableContainerBlockEntityInvoker {
    /** Reads the backing list without triggering loot table generation. */
    @Invoker("getInvStackList")
    class_2371<class_1799> shadowlink$getInvStackList();
}
