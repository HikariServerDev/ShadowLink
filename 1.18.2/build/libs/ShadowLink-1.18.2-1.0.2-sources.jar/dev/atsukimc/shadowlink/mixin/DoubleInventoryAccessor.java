package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1258;
import net.minecraft.class_1263;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1258.class)
public interface DoubleInventoryAccessor {
    @Accessor("first")
    class_1263 shadowlink$getFirst();

    @Accessor("second")
    class_1263 shadowlink$getSecond();
}
