package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1277;
import net.minecraft.class_1799;
import net.minecraft.class_2371;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1277.class)
public interface SimpleInventoryAccessor {
    @Accessor("stacks")
    class_2371<class_1799> shadowlink$getStacks();
}
