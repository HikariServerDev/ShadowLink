package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1277;
import net.minecraft.class_1496;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1496.class)
public interface HorseBaseEntityAccessor {
    @Accessor("items")
    class_1277 shadowlink$getItems();
}
