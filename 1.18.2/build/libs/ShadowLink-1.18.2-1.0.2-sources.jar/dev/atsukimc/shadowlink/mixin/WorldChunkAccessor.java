package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_2818;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_2818.class)
public interface WorldChunkAccessor {
    @Accessor("loadedToWorld")
    boolean shadowlink$isLoadedToWorld();
}
