package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1263;
import net.minecraft.class_1496;
import net.minecraft.class_1724;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1724.class)
public interface HorseScreenHandlerAccessor {
    @Accessor("inventory")
    class_1263 shadowlink$getInventory();

    @Accessor("entity")
    class_1496 shadowlink$getEntity();
}
