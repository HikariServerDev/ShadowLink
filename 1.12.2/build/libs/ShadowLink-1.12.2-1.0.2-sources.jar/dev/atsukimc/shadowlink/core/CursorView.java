package dev.atsukimc.shadowlink.core;

import net.minecraft.class_1071;
import net.minecraft.class_1982;
import net.minecraft.class_798;
import net.minecraft.class_849;
import net.minecraft.class_988;

/** Read-only single-slot view of a player's cursor stack, so it can be scanned like any holder. */
final class CursorView implements class_849 {
    private final class_798 player;

    CursorView(class_798 player) {
        this.player = player;
    }

    @Override
    public int method_2388() {
        return 1;
    }

    @Override
    public boolean method_13922() {
        return this.method_2381(0).method_13654();
    }

    @Override
    public class_1071 method_2381(int slot) {
        return this.player.field_3999.method_3150();
    }

    @Override
    public class_1071 method_2382(int slot, int amount) {
        throw new UnsupportedOperationException();
    }

    @Override
    public class_1071 method_2386(int slot) {
        throw new UnsupportedOperationException();
    }

    @Override
    public void method_2383(int slot, class_1071 stack) {
        throw new UnsupportedOperationException();
    }

    @Override
    public int method_2389() {
        return 64;
    }

    @Override
    public void method_543() {
    }

    @Override
    public boolean method_2384(class_988 player) {
        return false;
    }

    @Override
    public void method_10894(class_988 player) {
    }

    @Override
    public void method_10895(class_988 player) {
    }

    @Override
    public boolean method_5338(int slot, class_1071 stack) {
        return false;
    }

    @Override
    public int method_10892(int key) {
        return 0;
    }

    @Override
    public void method_10893(int id, int value) {
    }

    @Override
    public int method_10896() {
        return 0;
    }

    @Override
    public void method_10897() {
        throw new UnsupportedOperationException();
    }

    @Override
    public String method_2518() {
        return "shadowlink.cursor";
    }

    @Override
    public boolean method_5339() {
        return false;
    }

    @Override
    public class_1982 method_6344() {
        throw new UnsupportedOperationException();
    }
}
