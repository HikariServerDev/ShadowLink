package dev.atsukimc.shadowlink.core;

import dev.atsukimc.shadowlink.mixin.FurnaceBlockEntityAccessor;
import dev.atsukimc.shadowlink.mixin.HorseBaseEntityAccessor;
import dev.atsukimc.shadowlink.mixin.LootableContainerBlockEntityInvoker;
import dev.atsukimc.shadowlink.mixin.SimpleInventoryAccessor;
import dev.atsukimc.shadowlink.mixin.StorageMinecartEntityAccessor;
import net.minecraft.class_1071;
import net.minecraft.class_1574;
import net.minecraft.class_221;
import net.minecraft.class_2737;
import net.minecraft.class_3114;
import net.minecraft.class_3136;
import net.minecraft.class_322;
import net.minecraft.class_849;
import net.minecraft.class_852;
import net.minecraft.class_864;

/**
 * Side-effect free slot access.
 * <p>
 * {@code Inventory.getInvStack/setInvStack} are not neutral on several vanilla inventories:
 * lootable containers generate their loot table, furnaces reset their cook timer, most of them
 * clamp the stack count and fire comparator updates through markDirty. Observing or re-linking
 * a shadow must cause none of that, so the backing list is used directly wherever vanilla has one.
 */
final class InventoryAccess {
    private static final class_322 EMPTY_SNAPSHOT = new class_322();

    private InventoryAccess() {
    }

    private static class_3114<class_1071> backingList(class_849 inventory) {
        if (inventory instanceof class_2737) {
            // Chests, hoppers, dispensers/droppers and shulker boxes.
            return ((LootableContainerBlockEntityInvoker) inventory).shadowlink$getInvStackList();
        }
        if (inventory instanceof class_221) {
            return ((FurnaceBlockEntityAccessor) inventory).shadowlink$getStacks();
        }
        if (inventory instanceof class_1574) {
            return ((StorageMinecartEntityAccessor) inventory).shadowlink$getInventory();
        }
        if (inventory instanceof class_852) {
            return ((SimpleInventoryAccessor) inventory).shadowlink$getStacks();
        }
        // PlayerInventory, BrewingStandBlockEntity: plain getInvStack/setInvStack without side effects.
        return null;
    }

    static int size(class_849 inventory) {
        class_3114<class_1071> list = backingList(inventory);
        return list != null ? list.size() : inventory.method_2388();
    }

    static class_1071 get(class_849 inventory, int slot) {
        class_3114<class_1071> list = backingList(inventory);
        if (list != null) {
            return slot >= 0 && slot < list.size() ? list.get(slot) : class_1071.field_15108;
        }
        return slot >= 0 && slot < inventory.method_2388() ? inventory.method_2381(slot) : class_1071.field_15108;
    }

    static void set(class_849 inventory, int slot, class_1071 stack) {
        class_3114<class_1071> list = backingList(inventory);
        if (list != null) {
            list.set(slot, stack);
        } else {
            inventory.method_2383(slot, stack);
        }
    }

    /** The slot container of an entity, or null if this entity type is not tracked. */
    static class_849 inventoryOf(class_864 entity) {
        if (entity instanceof class_849) {
            return (class_849) entity;
        }
        if (entity instanceof class_3136) {
            return ((HorseBaseEntityAccessor) entity).shadowlink$getItems();
        }
        return null;
    }

    /**
     * NBT form of a stack as it looks after one save/load cycle. Loading is not an exact
     * inverse of saving (e.g. damageable items gain {@code Damage:0}), so both sides of every
     * comparison go through the same round trip. Empty stacks are an empty compound.
     */
    static class_322 snapshotOf(class_1071 stack) {
        if (stack == null || stack.method_13654()) {
            return EMPTY_SNAPSHOT;
        }
        class_1071 reloaded = fromNbt(stack.method_3424(new class_322()));
        if (reloaded.method_13654()) {
            return EMPTY_SNAPSHOT;
        }
        return reloaded.method_3424(new class_322());
    }

    static class_1071 fromSnapshot(class_322 snapshot) {
        // The constructor may post-process the compound in place, hence the copy.
        return snapshot.method_4386() ? class_1071.field_15108 : fromNbt(snapshot.method_13470());
    }

    private static class_1071 fromNbt(class_322 nbt) {
        try {
            class_1071 stack = new class_1071(nbt);
            return stack.method_13654() ? class_1071.field_15108 : stack;
        } catch (RuntimeException e) {
            return class_1071.field_15108;
        }
    }
}
