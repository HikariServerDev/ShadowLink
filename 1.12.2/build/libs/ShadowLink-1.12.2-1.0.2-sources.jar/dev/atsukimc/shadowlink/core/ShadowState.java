package dev.atsukimc.shadowlink.core;

import net.minecraft.class_322;
import net.minecraft.class_92;

/**
 * Vanilla save-data carrier: {@code <world>/data/shadowlink.dat}, written with every world save.
 * The state manager instantiates it reflectively, so the owning manager is passed through
 * {@link ShadowManager#stateOwner}.
 */
public final class ShadowState extends class_92 {
    static final String ID = "shadowlink";

    private final ShadowManager manager;

    public ShadowState(String id) {
        super(id);
        this.manager = ShadowManager.stateOwner;
    }

    @Override
    public void method_188(class_322 nbt) {
        this.manager.readNbtSafely(nbt);
    }

    @Override
    public class_322 method_191(class_322 nbt) {
        return this.manager.writeNbt(nbt);
    }

    /**
     * The saved snapshot has to describe the canonical stacks as they are at save time, and
     * those change without notifying anyone, so the state is rewritten on every save while
     * at least one group exists.
     */
    @Override
    public boolean method_190() {
        return super.method_190() || this.manager.hasGroups();
    }
}
