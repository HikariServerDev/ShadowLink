package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1719;
import net.minecraft.class_3136;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_3136.class)
public interface HorseBaseEntityAccessor {
    @Accessor("animalInventory")
    class_1719 shadowlink$getItems();
}
