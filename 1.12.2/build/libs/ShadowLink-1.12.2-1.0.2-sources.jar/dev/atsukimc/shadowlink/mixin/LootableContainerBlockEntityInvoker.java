package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1071;
import net.minecraft.class_2737;
import net.minecraft.class_3114;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Invoker;

@Mixin(class_2737.class)
public interface LootableContainerBlockEntityInvoker {
    /** Backing list of chests, hoppers, dispensers and shulker boxes; no loot table generation. */
    @Invoker("method_13730")
    class_3114<class_1071> shadowlink$getInvStackList();
}
