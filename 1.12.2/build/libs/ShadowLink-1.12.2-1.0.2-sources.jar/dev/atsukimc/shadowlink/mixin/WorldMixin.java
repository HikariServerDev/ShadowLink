package dev.atsukimc.shadowlink.mixin;

import dev.atsukimc.shadowlink.core.ShadowManager;
import net.minecraft.class_1150;
import net.minecraft.class_3136;
import net.minecraft.class_849;
import net.minecraft.class_864;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Load / unload of inventory-carrying entities (storage minecarts, horses, donkeys, llamas). */
@Mixin(class_1150.class)
public abstract class WorldMixin {
    @Inject(method = "onEntitySpawned", at = @At("TAIL"))
    private void shadowlink$spawned(class_864 entity, CallbackInfo ci) {
        if (entity instanceof class_849 || entity instanceof class_3136) {
            ShadowManager.onEntityLoaded(entity);
        }
    }

    // Reached both for a chunk unload and for removal (death, portal); the manager tells them
    // apart by Entity#removed.
    @Inject(method = "onEntityRemoved", at = @At("HEAD"))
    private void shadowlink$removed(class_864 entity, CallbackInfo ci) {
        if (entity instanceof class_849 || entity instanceof class_3136) {
            ShadowManager.onEntityUnloading(entity);
        }
    }
}
