package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_2610;
import net.minecraft.class_848;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_848.class)
public interface DoubleInventoryAccessor {
    @Accessor("mainInventory")
    class_2610 shadowlink$getFirst();

    @Accessor("secondaryInventory")
    class_2610 shadowlink$getSecond();
}
