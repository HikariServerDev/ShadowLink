package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1071;
import net.minecraft.class_221;
import net.minecraft.class_3114;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_221.class)
public interface FurnaceBlockEntityAccessor {
    @Accessor("field_15154")
    class_3114<class_1071> shadowlink$getStacks();
}
