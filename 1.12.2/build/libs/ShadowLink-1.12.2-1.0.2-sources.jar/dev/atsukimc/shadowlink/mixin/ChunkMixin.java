package dev.atsukimc.shadowlink.mixin;

import dev.atsukimc.shadowlink.core.ShadowManager;
import net.minecraft.class_1150;
import net.minecraft.class_1196;
import net.minecraft.class_226;
import net.minecraft.class_795;
import net.minecraft.class_849;
import org.spongepowered.asm.mixin.Final;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(class_1196.class)
public abstract class ChunkMixin {
    @Shadow @Final private class_1150 world;
    @Shadow private boolean loaded;

    /**
     * The chunk's block entities were just read from disk but are not yet handed to the world,
     * so re-linking never registers anything twice.
     */
    @Inject(method = "loadToWorld", at = @At("HEAD"))
    private void shadowlink$loading(CallbackInfo ci) {
        if (!this.loaded && this.world instanceof class_795) {
            ShadowManager.onChunkLoaded((class_795) this.world, (class_1196) (Object) this);
        }
    }

    /** The chunk is serialized right after this call, with its block entities still intact. */
    @Inject(method = "unloadFromWorld", at = @At("HEAD"))
    private void shadowlink$unloading(CallbackInfo ci) {
        if (this.world instanceof class_795) {
            ShadowManager.onChunkUnloading((class_795) this.world, (class_1196) (Object) this);
        }
    }

    // A block entity put into an already loaded chunk may carry a tracked stack to a new position.
    @Inject(method = "addBlockEntity", at = @At("TAIL"))
    private void shadowlink$blockEntityAdded(class_226 blockEntity, CallbackInfo ci) {
        if (this.loaded && blockEntity instanceof class_849 && this.world instanceof class_795) {
            ShadowManager.onBlockEntityPlaced((class_795) this.world, blockEntity);
        }
    }
}
