package dev.atsukimc.shadowlink.mixin;

import dev.atsukimc.shadowlink.core.ShadowManager;
import net.minecraft.class_1002;
import net.minecraft.class_1071;
import net.minecraft.class_2679;
import net.minecraft.class_798;
import net.minecraft.class_988;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(class_1002.class)
public abstract class ScreenHandlerMixin {
    // HEAD rather than RETURN: a click that creates a shadow may end in an exception, so the
    // handler is only queued here and inspected afterwards by ShadowManager.
    @Inject(method = "method_3252", at = @At("HEAD"))
    private void shadowlink$clicked(int slotIndex, int button, class_2679 action, class_988 player, CallbackInfoReturnable<class_1071> cir) {
        if (player instanceof class_798) {
            ShadowManager.onSlotClick((class_1002) (Object) this, (class_798) player);
        }
    }
}
