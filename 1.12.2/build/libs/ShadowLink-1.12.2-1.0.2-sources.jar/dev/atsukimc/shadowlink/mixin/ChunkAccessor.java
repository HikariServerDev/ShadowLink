package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1196;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1196.class)
public interface ChunkAccessor {
    @Accessor("loaded")
    boolean shadowlink$isLoaded();
}
