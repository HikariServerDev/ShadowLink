package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1026;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1026.class)
public interface SlotAccessor {
    @Accessor("invSlot")
    int shadowlink$getIndex();
}
