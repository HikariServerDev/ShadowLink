package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1071;
import net.minecraft.class_1574;
import net.minecraft.class_3114;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1574.class)
public interface StorageMinecartEntityAccessor {
    @Accessor("inventory")
    class_3114<class_1071> shadowlink$getInventory();
}
