package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1071;
import net.minecraft.class_3114;
import net.minecraft.class_852;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_852.class)
public interface SimpleInventoryAccessor {
    @Accessor("content")
    class_3114<class_1071> shadowlink$getStacks();
}
