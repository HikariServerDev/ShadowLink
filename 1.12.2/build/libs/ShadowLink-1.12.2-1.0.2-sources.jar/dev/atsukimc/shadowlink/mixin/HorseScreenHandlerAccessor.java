package dev.atsukimc.shadowlink.mixin;

import net.minecraft.class_1720;
import net.minecraft.class_3136;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;

@Mixin(class_1720.class)
public interface HorseScreenHandlerAccessor {
    @Accessor("field_15101")
    class_3136 shadowlink$getEntity();
}
